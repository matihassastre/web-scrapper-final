﻿def test_import():
    import webscraper_futbol  # noqa: F401
